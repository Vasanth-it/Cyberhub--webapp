<?php
session_start();
$conn = mysqli_connect("localhost","root","","tb_user");
?>

        